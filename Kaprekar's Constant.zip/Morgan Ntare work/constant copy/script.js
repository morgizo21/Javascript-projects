function sortAscending(array) {
    for (let i = 0; i < array.length; i++) {
        for (let j = i + 1; j < array.length; j++) {
            if (array[i] > array[j]) {
                let temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
    }
}

function sortDescending(array) {
    for (let i = 0; i < array.length; i++) {
        for (let j = i + 1; j < array.length; j++) {
            if (array[i] < array[j]) {
                let temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
    }
}

function calculate() {
    let numInput = document.getElementById('numInput').value;
    let outputDiv = document.getElementById('output');
    outputDiv.innerHTML = '';

    // Check if the input is only digits and has 3 or 4 characters
    if (numInput.length < 3 || numInput.length > 4) {
        outputDiv.innerHTML = "<p>Please enter a valid 3-digit or 4-digit number.</p>";
        return;
    }

    for (let i = 0; i < numInput.length; i++) {
        let ch = numInput[i];
        if (ch < '0' || ch > '9') {
            outputDiv.innerHTML = "<p>Please enter digits only.</p>";
            return;
        }
    }

    // Check if all digits are the same
    let allSame = true;
    for (let i = 1; i < numInput.length; i++) {
        if (numInput[i] !== numInput[0]) {
            allSame = false;
            break;
        }
    }

    if (allSame) {
        outputDiv.innerHTML = "<p>Please enter a number with at least two different digits.</p>";
        return;
    }

    let isThreeDigit = numInput.length === 3;
    let goal = isThreeDigit ? "495" : "6174";
    let digitCount = isThreeDigit ? 3 : 4;

    // Pad with leading zeroes if needed
    while (numInput.length < digitCount) {
        numInput = "0" + numInput;
    }

    let currentNumber = numInput;
    let iterations = 0;
    const MAX_ITERATIONS = 7;

    while (currentNumber !== goal && iterations < MAX_ITERATIONS) {
        let digits = [];

        for (let i = 0; i < digitCount; i++) {
            digits.push(parseInt(currentNumber[i]));
        }

        let ascArray = [...digits];
        let dscArray = [...digits];

        sortAscending(ascArray);
        sortDescending(dscArray);

        let ascStr = "";
        let dscStr = "";

        for (let i = 0; i < digitCount; i++) {
            ascStr += ascArray[i];
            dscStr += dscArray[i];
        }

        let ascNum = parseInt(ascStr);
        let dscNum = parseInt(dscStr);
        let result = dscNum - ascNum;

        currentNumber = result.toString();
        while (currentNumber.length < digitCount) {
            currentNumber = "0" + currentNumber;
        }

        iterations++;
        outputDiv.innerHTML += "<p>Step " + iterations + ": " + dscStr + " - " + ascStr + " = " + currentNumber + "</p>";
    }

    if (currentNumber === goal) {
        outputDiv.innerHTML += "<p>✅ Reached " + goal + " in " + iterations + " step(s)!</p>";
    } else {
        outputDiv.innerHTML += "<p>❌ Did not reach the constant within " + MAX_ITERATIONS + " steps.</p>";
    }
}
