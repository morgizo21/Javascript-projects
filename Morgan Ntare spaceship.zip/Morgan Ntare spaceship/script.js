// Create the Spaceship class
class Spaceship {
    constructor(name, model, speed, shieldStrength, cargoCapacity) {
      // These are the spaceship's properties (data)
      this.name = name;
      this.model = model;
      this.speed = speed;
      this.shieldStrength = shieldStrength;
      this.cargoCapacity = cargoCapacity;
      this.weapons = []; // Start with an empty list of weapons
    }
  
    // Method to "launch" the spaceship
    launch() {
      return "🚀 Spaceship " + this.name + " has launched at " + this.speed + " km/s!";
    }
  
    // Method to get the spaceship's status/info
    status() {
      // Join all the weapons with a comma, or show "None" if there are no weapons
      let weaponText = this.weapons.length > 0 ? this.weapons.join(", ") : "None";
  
      // Return a message showing all the details
      return (
        "Name: " + this.name + "<br>" +
        "Model: " + this.model + "<br>" +
        "Speed: " + this.speed + " km/s<br>" +
        "Shield Strength: " + this.shieldStrength + "/100<br>" +
        "Cargo Capacity: " + this.cargoCapacity + " tons<br>" +
        "Weapons: " + weaponText + "<br><br>" +
        this.launch()
      );
    }
  
    // Method to add a weapon if the input is not empty
    addWeapon(weaponName) {
      if (weaponName.trim() !== "") {
        this.weapons.push(weaponName);
      }
    }
  }
  
  // When the form is submitted, do this:
  document.getElementById("spaceshipForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Stop the page from refreshing
  
    // Get all the values from the form
    const name = document.getElementById("name").value;
    const model = document.getElementById("model").value;
    const speed = document.getElementById("speed").value;
    const shield = document.getElementById("shield").value;
    const cargo = document.getElementById("cargo").value;
    const weapon = document.getElementById("weapon").value;
  
    // Create a new Spaceship object using the class
    const myShip = new Spaceship(name, model, speed, shield, cargo);
  
    // Add the weapon if it's not empty
    myShip.addWeapon(weapon);
  
    // Show the status on the webpage
    const fleetArea = document.getElementById("fleetList");
    const shipInfo = document.createElement("div");
    shipInfo.innerHTML = myShip.status();
    shipInfo.classList.add("ship-card");
    fleetArea.appendChild(shipInfo);
  
    // Clear the form for the next spaceship
    document.getElementById("spaceshipForm").reset();
  });
  
  // Reset button clears all spaceships from the screen
  document.getElementById("resetFleet").addEventListener("click", function() {
    document.getElementById("fleetList").innerHTML = "";
  });
  