/*    JavaScript 7th Edition
      Chapter 2
      Project 02-04

      Application to calculate the cost of a restaurant order plus tax
      Author: Morgan Ntare
      Date: 02/16/2025

      Filename: project02-04.js
 */
 
/*    JavaScript 7th Edition
      Chapter 2
      Project 02-04

      Food Order Total Calculation
      Author: Morgan Ntare
      Date: 02/16/2025

      Filename: project02-04.js
*/

// Constant Prices
const CHICKEN_PRICE = 10.95;
const HALIBUT_PRICE = 13.95;
const BURGER_PRICE = 9.95;
const SALMON_PRICE = 18.95;
const SALAD_PRICE = 7.95;
const SALES_TAX = 0.07;

// Function to calculate the total cost
function calcTotal() {
    let cost = 0;

    // Check if each item is selected and add its price to the cost
    if (document.getElementById("chicken").checked) cost += CHICKEN_PRICE;
    if (document.getElementById("halibut").checked) cost += HALIBUT_PRICE;
    if (document.getElementById("burger").checked) cost += BURGER_PRICE;
    if (document.getElementById("salmon").checked) cost += SALMON_PRICE;
    if (document.getElementById("salad").checked) cost += SALAD_PRICE;

    // Calculate tax and total cost
    let tax = cost * SALES_TAX;
    let totalCost = cost + tax;

    // Update the totals in the HTML
    document.getElementById("foodTotal").innerHTML = formatCurrency(cost);
    document.getElementById("foodTax").innerHTML = formatCurrency(tax);
    document.getElementById("totalBill").innerHTML = formatCurrency(totalCost);
}

// Function to format currency
function formatCurrency(value) {
    return "$" + value.toFixed(2);
}

// Add event listeners to checkboxes to trigger the total calculation
document.getElementById("chicken").addEventListener("click", calcTotal);
document.getElementById("halibut").addEventListener("click", calcTotal);
document.getElementById("burger").addEventListener("click", calcTotal);
document.getElementById("salmon").addEventListener("click", calcTotal);
document.getElementById("salad").addEventListener("click", calcTotal);

// Initial calculation to set default values
calcTotal();
