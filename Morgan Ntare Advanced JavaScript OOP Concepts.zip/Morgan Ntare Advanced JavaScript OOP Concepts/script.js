"use strict";

// Morgan Ntare.
function createPlayer() {

    class Player {
        constructor(name, health, mana, level){
            // assign the values to properties
            this.name = name;
            this.health = health;
            this.mana = mana;
            this.level = level;
    }

    displayStats() {
      return `Name: ${this.name}, Health: ${this.health}, Mana: ${this.mana}, Level: ${this.level}`;
    }  
}
    // get players name. 
    let playerName = document.getElementById("playerName").value;

    // create player object.
    let player = new Player(playerName, 100, 50, 1);

    // display stats in paragraph.
    document.getElementById("output-class").textContent = player.displayStats();
    
}

// Inheritance. 
class Character {
    power(){
        return "No special Power";
    }
}

class Warrior extends Character {
    power() {
        return " ⚔ Warrior Power is Mighty Warrior sword"
    }
}

class Mage extends Character {
    power() {
        return " 🔥 Mage power is Fireball"
    }
}

class Rogue extends Character {
    power() {
        return " 💪 Rogue Power is backstab."
    }
}


// function for button click
function selectCharacter(){
    const selected = document.getElementById("characterType").value; 

    let character;
    // choose correct class. 
    if (selected === "warrior")
        character = new Warrior();
    else if (selected === "mage")
        character = new Mage();
    else if (selected === "rogue")
        character = new Rogue();
    
// show resutls
document.getElementById("output-inheritance").textContent = character.power();
}


// Method overriddng.

class Enemy {
    attack() {
       return "Enemy attacks" 
    }
}

class Orc extends Enemy {
    attack () {
        return " 🔥 Orc smashes"
    }
}

class Vampire extends Enemy {
    attack () {
        return "🧛‍♀️ Vampire bites"
    }
}

// function for button click
function showEnemyActions(){

    const enemies = [new Enemy(), new Orc(), new Vampire()];

    let result ="";

    // loop through to get each enemies attacking action
    for (let enemy of enemies){
        result += enemy.attack() +"\n";
    }

    document.getElementById("output-override").textContent = result;
    
}

// Encapsulation. 

// Create the GameSettings class
class GameSettings {
  // Make a private variable using #
  #difficulty = "Normal"; // starting value

  // This method lets us change the difficulty
  setDifficulty(value) {
    // Only accept valid values
    if (value === "Easy" || value === "Normal" || value === "Hard") {
      this.#difficulty = value;
    }
  }

  // This method returns the current difficulty
  getDifficulty() {
    return "Current difficulty is: " + this.#difficulty;
  }
}

// This function runs when the Apply Settings button is clicked
function updateSettings() {
  // Get the selected option from the dropdown
  let selected = document.getElementById("difficultySelect").value;

  // Create a new GameSettings object
  let game = new GameSettings();

  // Set the difficulty using the selected value
  game.setDifficulty(selected);

  // Show the difficulty in the page
  document.getElementById("output-encapsulation").textContent = game.getDifficulty();
}

// Abstraction 
// Base class
class Puzzle {
    // This method is meant to be overridden by child classes
    solve() {
      return "This puzzle has no solution yet.";
    }
  }
  
  // Subclass for a riddle puzzle
  class RiddlePuzzle extends Puzzle {
    solve() {
      return "🎉Riddle solved: The answer is 'Shadow'.";
    }
  }
  
  // Subclass for a math puzzle
  class MathPuzzle extends Puzzle {
    solve() {
      return " 🧮 Math solved: 12 + 8 = 20.";
    }
  }
  
  // When user clicks "Solve Riddle" button
  function solveRiddle() {
    let puzzle = new RiddlePuzzle();
    document.getElementById("output-abstraction").textContent = puzzle.solve();
  }
  
  // When user clicks "Solve Math" button
  function solveMath() {
    let puzzle = new MathPuzzle();
    document.getElementById("output-abstraction").textContent = puzzle.solve();
  }

// Polymorphism
// base NPC class
class NPC {
    interact(){
        return "The NPC says something";
    }
}

// Subclass: Merchant
class Merchant extends NPC {
    interact() {
      return "🛍 Merchant: Want to buy something?";
    }
  }
  
  // Subclass: Healer
  class Healer extends NPC {
    interact() {
      return "❤ Healer: Let me heal your wounds.";
    }
  }
  
  // Subclass: Blacksmith
  class Blacksmith extends NPC {
    interact() {
      return "🔨 Blacksmith: I can upgrade your gear.";
    }
  }

  // when the user clicks "talks to NPCS" button.
function interactWithNPCs(){
    // create array of npcs
    const npcs = [new Merchant(), new Healer(), new Blacksmith()];

    let messages = [];

    for (let npc of npcs){
        messages.push(npc.interact());
    }

    document.getElementById("output-polymorphism").textContent = messages.join(" | ");

}

// Static Method - Game Calculations. 
class GameUtils {
    static calculateXP(level, enemies){
        return level * enemies * 10;
    }

    static convertGoldToGems(gold){
        return Math.floor(gold/50)
    } 
}
    // function for calculate button.
    function calculateGameStats(){

    const level = document.getElementById("levelInput").value;
    const enemies = document.getElementById("enemyCount").value;
    const gold = document.getElementById("goldInput").value;

    // calculate using static method.
    const xp = GameUtils.calculateXP(level,enemies);
    const gems = GameUtils.convertGoldToGems(gold);

    // display the result.
    document.getElementById("output-static-method").textContent = `Xp is ${xp}, | Gems is ${gems}`;
    
    
    }
