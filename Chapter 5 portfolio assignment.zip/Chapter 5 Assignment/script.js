let clockInterval;

document.getElementById("userForm").addEventListener("submit", function (e) {
  e.preventDefault(); 

  
  const name = document.getElementById("username").value;
  const email = document.getElementById("email").value;
  const lang = document.getElementById("language").value;
  const sub = document.querySelector('input[name="subscribe"]:checked')?.value || "No";

  
  const container = document.getElementById("profileInfo");
  container.innerHTML = "";

  
  const info = [
    ["Name", name],
    ["Email", email],
    ["Favorite Language", lang],
    ["Subscribed", sub],
  ];

  // Add the information to the page
  info.forEach(function (item) {
    let label = item[0];
    let value = item[1];

    let p = document.createElement("p");
    p.textContent = label + ": " + value; 
    container.appendChild(p); 
  });

  /// Display the portfolio section if it was hidden
  document.getElementById("portfolio").classList.remove("hidden");
});



function insertWelcomeMessage() {

  if (document.getElementById("welcomeMsg")) return;

  let welcomeMessage = document.createElement("p");
  welcomeMessage.id = "welcomeMsg";
  welcomeMessage.textContent = " 😁 Welcome to your personalized dashboard";
  welcomeMessage.style.fontWeight = "bold";
  welcomeMessage.style.color = "green";

  let heading = document.querySelector("h1");
  document.body.insertBefore(welcomeMessage, heading);
}



function cloneBadge() {
  const badge = document.querySelector(".badge");
  if (badge) {
    const newBadge = badge.cloneNode(true); 
    document.getElementById("badgeContainer").appendChild(newBadge); 
  }
}



function removeBadge() {
  const container = document.getElementById("badgeContainer");
  const badges = container.querySelectorAll(".badge");


  if (badges.length > 1) {
    container.removeChild(badges[badges.length - 1]);
  }
}



function showDelayedMessage() {
  setTimeout(function () {
    alert("Thank you for using the dashboard!");
  }, 2000); 
}



function openPreview() {
  const newTab = window.open("", "_blank"); 
  newTab.document.write("<h1> This is your portfolio preview!</h1>");
}



function changeTheme() {
  document.body.classList.toggle("blue-theme");
}



function updateClock() {
  const now = new Date(); 
  const clock = document.getElementById("clock");
  clock.textContent = now.toLocaleTimeString();
}


function stopClock() {
  clearInterval(clockInterval); 
}


clockInterval = setInterval(updateClock, 1000);


document.getElementById("footerInfo").textContent =
  "Screen: " + screen.width + "x" + screen.height +
  " | Browser: " + navigator.userAgent;
