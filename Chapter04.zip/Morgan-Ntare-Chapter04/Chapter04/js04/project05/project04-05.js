"use strict";

/*    JavaScript 7th Edition
      Chapter 4
      Project 04-05

      Degrees <-> Radians Converter
      Author: Morgan Ntare
      Date: 03/23/2025  

      Filename: project04-05.js
 */

// Function to convert degrees to radians 
function degreesToRadians(degrees) {
   return degrees * Math.PI / 180;
}

// Function to convert radians to degrees
function radiansToDegrees(radians) {
   return radians * 180 / Math.PI;
}

// Event handler: radians → degrees
document.getElementById("rValue").onchange = function() {
   let radians = parseFloat(document.getElementById("rValue").value);
   console.log("Radians = " + radians);
   document.getElementById("aValue").value = formatValue3(radiansToDegrees(radians));
};

// Event handler: degrees → radians
document.getElementById("aValue").onchange = function() {
   let degrees = parseFloat(document.getElementById("aValue").value);
   console.log("Degrees = " + degrees);
   document.getElementById("rValue").value = formatValue3(degreesToRadians(degrees));
};

/* ================================================================= */

// Format value to 3 decimal places
function formatValue3(value) {
   return value.toFixed(3);
}
