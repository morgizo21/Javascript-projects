// Wait for the page to load before running the script
document.addEventListener("DOMContentLoaded", function () {
    const buttons = document.querySelectorAll("button");
    const userChoiceDisplay = document.getElementById("userChoice");
    const computerChoiceDisplay = document.getElementById("computerChoice");
    const outcomeDisplay = document.getElementById("outcome");

    // Possible choices
    let choices = ["Rock", "Paper", "Scissors"];

    // Function to get a random computer choice WITHOUT using Math.floor()
    function getComputerChoice() {
        let randomIndex = (Math.random() * choices.length); // Generates a number between 0 and 3 (not included)
        
        if (randomIndex < 1) {
            return choices[0]; // Rock
        } else if (randomIndex < 2) {
            return choices[1]; // Paper
        } else {
            return choices[2]; // Scissors
        }
    }

    // Function to determine the winner
    function getWinner(userChoice, computerChoice) {
        if (userChoice === computerChoice) {
            return "It's a tie!";
        } else if (
            (userChoice === "Rock" && computerChoice === "Scissors") ||
            (userChoice === "Paper" && computerChoice === "Rock") ||
            (userChoice === "Scissors" && computerChoice === "Paper")
        ) {
            return "You win!";
        } else {
            return "Computer wins!";
        }
    }

    // Add event listeners to each button
    buttons.forEach(button => {
        button.addEventListener("click", function () {
            let userChoice = button.textContent;
            let computerChoice = getComputerChoice();
            let result = getWinner(userChoice, computerChoice);

            // Update the result display
            userChoiceDisplay.textContent = "Your Choice: " + userChoice;
            computerChoiceDisplay.textContent = "Computer's Choice: " + computerChoice;
            outcomeDisplay.textContent = "Result: " + result;
        });
    });
});
