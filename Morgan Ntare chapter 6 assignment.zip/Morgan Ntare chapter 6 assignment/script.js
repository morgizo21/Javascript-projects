// Morgan Ntare

// Update the total cost when the number of tickets changes
document.getElementById("ticketCount").addEventListener("input", function () {
    const ticketCount = parseInt(this.value);
    const totalCost = ticketCount * 10;
    document.getElementById("cost").value = totalCost.toFixed(2);
  });
  
  // Validate the name field using pattern
  document.getElementById("fullName").setAttribute("pattern", "[A-Za-z ]{3,}");
  document.getElementById("fullName").addEventListener("invalid", function () {
    this.setCustomValidity("Please enter a valid name (min 3 letters)");
  });
  document.getElementById("fullName").addEventListener("input", function () {
    this.setCustomValidity("");
  });
  
  // Handle form submission
  document.getElementById("registrationForm").addEventListener("submit", function (e) {
    e.preventDefault(); // Stop default form submission
  
    const name = document.getElementById("fullName").value.trim();
    const email = document.getElementById("email").value.trim();
    const ticketCount = parseInt(document.getElementById("ticketCount").value);
    const session = document.getElementById("session").value;
    const eventCode = document.getElementById("eventCode").value;
  
    // Check which radio button is selected
    const sizeOption = document.querySelector("input[name='size']:checked");
    const size = sizeOption ? sizeOption.value : null;
  
    // Validate that all fields are filled
    if (!name || !email || !session || !size) {
      alert("Please complete all required fields.");
      return;
    }
  
    // Format cost using toLocaleString
    const totalCost = ticketCount * 10;
    const formattedCost = totalCost.toLocaleString("en-US", {
      style: "currency",
      currency: "USD"
    });
  
    // Display confirmation
    const confirmation = document.getElementById("confirmation");
    confirmation.innerHTML = `
      <h2>✅ Registration Successful!</h2>
      <p><strong>Name:</strong> ${name}</p>
      <p><strong>Email:</strong> ${email}</p>
      <p><strong>Session:</strong> ${session}</p>
      <p><strong>T-shirt Size:</strong> ${size}</p>
      <p><strong>Total Paid:</strong> ${formattedCost}</p>
      <p><strong>Event Code:</strong> ${eventCode}</p>
    `;
    confirmation.classList.remove("hidden");
  });
  
  // Hide confirmation when form is reset
  document.getElementById("registrationForm").addEventListener("reset", function () {
    setTimeout(function () {
      document.getElementById("confirmation").classList.add("hidden");
    }, 0);
  });
  